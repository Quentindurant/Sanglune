#!/usr/bin/env python3
"""Fabrique tous les sons de Sanglune par synthèse : aucun fichier emprunté, aucune licence à suivre.

Lames qui fendent l'air, chocs d'acier, cloches, tonnerre de la lune, et trois ambiances en boucle
(nuit pour les menus, duel, seigneur). Relancer ce script régénère assets/audio à l'identique (graine fixe).

    pip install numpy scipy
    python3 tools/generate_sounds.py
"""
import os
import wave

import numpy as np
from scipy import signal

RATE = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")
rng = np.random.default_rng(1337)


# --- Briques ---

def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def noise(seconds):
    return rng.uniform(-1.0, 1.0, int(seconds * RATE))


def pink(seconds):
    white = rng.normal(0, 1, int(seconds * RATE))
    b = [0.049922035, -0.095993537, 0.050612699, -0.004408786]
    a = [1, -2.494956002, 2.017265875, -0.522189400]
    return signal.lfilter(b, a, white)


def band(x, low, high, order=2):
    sos = signal.butter(order, [low, high], btype="band", fs=RATE, output="sos")
    return signal.sosfilt(sos, x)


def lowpass(x, cutoff, order=2):
    return signal.sosfilt(signal.butter(order, cutoff, btype="low", fs=RATE, output="sos"), x)


def highpass(x, cutoff, order=2):
    return signal.sosfilt(signal.butter(order, cutoff, btype="high", fs=RATE, output="sos"), x)


def sweep_band(x, f0, f1, width=0.6, steps=24):
    """Bruit filtré dont la bande glisse de f0 à f1 : le souffle d'une lame."""
    out = np.zeros_like(x)
    edges = np.linspace(0, len(x), steps + 1).astype(int)
    for i in range(steps):
        f = f0 + (f1 - f0) * i / max(steps - 1, 1)
        seg = band(x, max(40, f * (1 - width / 2)), min(RATE / 2 - 100, f * (1 + width / 2)))
        window = np.zeros_like(x)
        window[edges[i]:edges[i + 1]] = 1.0
        out += seg * signal.convolve(window, np.hanning(256) / 128, mode="same")
    return out


def env(n, attack, decay_time, sustain=0.0, release=None):
    t = np.arange(n) / RATE
    e = np.where(t < attack, t / max(attack, 1e-4), np.exp(-(t - attack) / max(decay_time, 1e-4)) * (1 - sustain) + sustain)
    if release:
        tail = int(release * RATE)
        e[-tail:] *= np.linspace(1, 0, tail)
    return e


def tone(freq, seconds, wave_kind="sine"):
    t = t_axis(seconds)
    if np.ndim(freq) == 0:
        phase = 2 * np.pi * freq * t
    else:
        phase = 2 * np.pi * np.cumsum(freq) / RATE
    if wave_kind == "saw":
        return 2 * ((phase / (2 * np.pi)) % 1.0) - 1
    if wave_kind == "square":
        return np.sign(np.sin(phase))
    return np.sin(phase)


def glide(f0, f1, seconds, curve=3.0):
    t = np.linspace(0, 1, int(seconds * RATE))
    return f1 + (f0 - f1) * np.exp(-curve * t)


def bell(freq, seconds, decay=0.8, bright=1.0):
    """Une cloche ou un acier : partiels inharmoniques qui s'éteignent chacun à leur vitesse."""
    t = t_axis(seconds)
    ratios = [1.0, 2.76, 5.40, 8.93, 13.34]
    amps = [1.0, 0.6 * bright, 0.35 * bright, 0.2 * bright, 0.1 * bright]
    out = np.zeros_like(t)
    for r, a in zip(ratios, amps):
        f = freq * r
        if f < RATE / 2 - 200:
            out += a * np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) * np.exp(-t * r ** 0.6 / decay)
    return fade_tail(out, min(0.3, seconds / 3))


def thump(f0, f1, seconds, curve=12.0):
    return tone(glide(f0, f1, seconds, curve), seconds) * env(int(seconds * RATE), 0.002, seconds / 4)


def reverb(x, seconds=1.2, wet=0.25, damp=3000):
    """Une salle de pierre : réponse en bruit qui s'éteint, assombrie."""
    x = fade_tail(x, 0.04) ## une source coupée net claquerait
    n = int(seconds * RATE)
    ir = rng.normal(0, 1, n) * np.exp(-np.linspace(0, 7, n))
    ir = lowpass(ir, damp)
    ir /= np.sqrt(np.sum(ir ** 2))
    tail = signal.fftconvolve(x, ir)
    dry = np.concatenate([x, np.zeros(len(tail) - len(x))])
    return dry * (1 - wet) + tail * wet


def mix(*parts):
    length = max(len(p) for p in parts)
    out = np.zeros(length)
    for p in parts:
        out[: len(p)] += fade_tail(p, 0.01)
    return out


def pad(x, seconds):
    return np.concatenate([np.zeros(int(seconds * RATE)), x])


def fade_tail(x, seconds=0.05):
    n = min(len(x), int(seconds * RATE))
    x = x.copy()
    x[-n:] *= np.linspace(1, 0, n)
    return x


def trim_silence(x, threshold=0.0005):
    loud = np.where(np.abs(x) > threshold * np.max(np.abs(x)))[0]
    return x[: loud[-1] + 1] if len(loud) else x


def save(name, x, peak=0.89, loop=False):
    if not loop: ## une boucle garde sa fin telle quelle, pour se raccorder à son début
        x = fade_tail(trim_silence(x))
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    data = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    path = os.path.join(OUT, name + ".wav")
    with wave.open(path, "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(RATE)
        f.writeframes(data.tobytes())
    print(f"{name:20s} {len(data) / RATE:5.2f} s")


def seamless(x, loop_seconds, fade=2.0):
    """Une boucle sans couture : la fin se fond dans le début."""
    n = int(loop_seconds * RATE)
    f = int(fade * RATE)
    out = x[:n].copy()
    ramp = np.linspace(0, 1, f)
    out[:f] = out[:f] * ramp + x[n:n + f] * (1 - ramp)
    return out


# --- Combat ---

def swing(low, high, seconds):
    n = noise(seconds)
    return sweep_band(n, low, high) * env(len(n), seconds * 0.35, seconds * 0.25)


def metal_clank(freq, seconds=0.35):
    return mix(bell(freq, seconds, decay=0.12, bright=1.2), highpass(noise(0.03), 2000) * 0.8)


def make_combat():
    save("lame_legere", swing(900, 3200, 0.2))
    save("lame_lourde", swing(350, 1500, 0.32))
    save("coup", reverb(mix(thump(140, 55, 0.22) * 1.2, lowpass(noise(0.06), 2500) * env(int(0.06 * RATE), 0.001, 0.015),
                            metal_clank(520, 0.25) * 0.35), 0.5, 0.15))
    save("coup_lourd", reverb(mix(thump(110, 38, 0.4) * 1.4, lowpass(noise(0.12), 1800) * env(int(0.12 * RATE), 0.001, 0.03),
                                  metal_clank(330, 0.4) * 0.4), 0.7, 0.2))
    save("parade", reverb(mix(bell(1250, 0.9, decay=0.35, bright=1.1), highpass(noise(0.02), 3000) * 0.9), 0.9, 0.25))
    crunch = np.tanh(band(noise(0.18), 400, 3500) * 6) * env(int(0.18 * RATE), 0.001, 0.05)
    save("garde_brisee", reverb(mix(crunch, bell(380, 0.7, decay=0.25) * 0.6, thump(120, 50, 0.3)), 0.8, 0.2))
    swell_t = 0.65
    swell = mix(sweep_band(noise(swell_t), 200, 2400, 0.8) * np.linspace(0, 1, int(swell_t * RATE)) ** 2,
                tone(glide(90, 360, swell_t, -2.0), swell_t, "saw") * 0.12 * np.linspace(0, 1, int(swell_t * RATE)))
    save("ultime", reverb(swell, 0.8, 0.3))
    save("ultime_impact", reverb(mix(thump(90, 28, 0.9, 6) * 1.6, lowpass(noise(0.4), 900) * env(int(0.4 * RATE), 0.001, 0.12),
                                     metal_clank(260, 0.6) * 0.5, bell(130, 1.2, decay=0.5) * 0.3), 1.6, 0.35))
    save("esquive", swing(1500, 4200, 0.15))
    save("saut", swing(500, 1800, 0.22) * 0.7)
    save("reception", lowpass(thump(90, 45, 0.18), 600))


# --- Seigneurs ---

def make_lords():
    save("egide", reverb(mix(bell(900, 1.0, decay=0.4, bright=1.3), bell(1350, 0.8, decay=0.3) * 0.4), 1.0, 0.3))
    scrape = band(noise(0.3), 2500, 7000) * env(int(0.3 * RATE), 0.01, 0.08) * (1 + 0.6 * np.sign(np.sin(2 * np.pi * 45 * t_axis(0.3))))
    save("ronces", scrape)
    hiss = highpass(noise(0.5), 4000) * env(int(0.5 * RATE), 0.04, 0.2) * (0.6 + 0.4 * np.sin(2 * np.pi * 18 * t_axis(0.5)))
    save("venin", hiss)
    save("vol_de_vie", reverb(tone(glide(260, 620, 0.35, -2.5), 0.35) * env(int(0.35 * RATE), 0.15, 0.1) * 0.8, 0.6, 0.35))
    hum_t = 1.0
    hum = tone(glide(70, 170, hum_t, -1.5), hum_t, "saw") * np.linspace(0.1, 1, int(hum_t * RATE)) * (0.7 + 0.3 * np.sin(2 * np.pi * 9 * t_axis(hum_t)))
    save("lune_presage", reverb(lowpass(hum, 900), 1.0, 0.3))
    crack = highpass(noise(0.25), 1500) * env(int(0.25 * RATE), 0.001, 0.04)
    rumble = lowpass(pink(1.4), 220) * env(int(1.4 * RATE), 0.02, 0.45) * 3
    save("lune_impact", reverb(mix(crack, rumble, thump(80, 30, 0.8, 5)), 1.5, 0.3))
    growl_t = 0.8
    growl = np.tanh(tone(glide(85, 62, growl_t, 2), growl_t, "saw") * 3) * (0.6 + 0.4 * np.sin(2 * np.pi * 26 * t_axis(growl_t)))
    save("furie", reverb(lowpass(growl, 1400) * env(int(growl_t * RATE), 0.05, 0.4), 0.8, 0.25))
    horn_t = 1.8
    horn = tone(55, horn_t, "saw") + tone(82.4, horn_t, "saw") * 0.6 + tone(110, horn_t, "saw") * 0.3
    horn = lowpass(horn, 700) * env(int(horn_t * RATE), 0.35, 1.2, release=0.3)
    save("seigneur", reverb(mix(horn, pad(bell(220, 2.0, decay=0.9) * 0.5, 0.25)), 2.0, 0.35))


# --- Rythme du match et interface ---

def chord_of_bells(freqs, gap, seconds=2.0, decay=0.8):
    parts = [pad(bell(f, seconds, decay=decay), i * gap) for i, f in enumerate(freqs)]
    return mix(*parts)


def make_ui():
    save("cloche_manche", reverb(bell(440, 2.2, decay=1.0), 2.0, 0.35))
    save("victoire", reverb(mix(chord_of_bells([293.7, 440.0, 587.3], 0.18, 2.4, 1.0),
                                lowpass(tone(73.4, 2.6, "saw"), 300) * env(int(2.6 * RATE), 0.2, 1.4) * 0.6), 2.2, 0.35))
    save("defaite", reverb(lowpass(mix(chord_of_bells([220.0, 174.6, 146.8], 0.35, 2.4, 1.2),
                                       tone(55, 2.8, "saw") * env(int(2.8 * RATE), 0.3, 1.5) * 0.5), 1500), 2.2, 0.4))
    click = mix(tone(1600, 0.03) * env(int(0.03 * RATE), 0.001, 0.008), highpass(noise(0.01), 3000) * 0.3)
    save("clic", click, peak=0.5)
    save("choix", reverb(chord_of_bells([880, 1318.5], 0.07, 0.7, 0.25), 0.6, 0.25), peak=0.6)
    save("rune_prete", reverb(bell(1760, 0.8, decay=0.4, bright=0.6), 0.8, 0.3), peak=0.55)
    sparkle = chord_of_bells([1046.5, 1318.5, 1568.0, 2093.0, 2637.0], 0.07, 1.4, 0.45)
    save("butin", reverb(mix(sparkle, sweep_band(noise(0.8), 3000, 7000, 0.5) * env(int(0.8 * RATE), 0.3, 0.2) * 0.3), 1.4, 0.35))
    save("trophee", reverb(mix(thump(80, 35, 0.8, 5), chord_of_bells([293.7, 370.0, 440.0, 587.3, 740.0], 0.11, 2.6, 1.1)), 2.4, 0.4))


# --- Ambiances en boucle ---

def drone(seconds, notes, cutoff=420, saw=True):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for f in notes:
        for detune in (-0.25, 0.25):
            out += tone(f + detune, seconds, "saw" if saw else "sine")
    # Le filtre respire lentement : la brume se lève et retombe.
    slow = lowpass(out, cutoff) * (0.75 + 0.25 * np.sin(2 * np.pi * t / 10.0))
    return slow / len(notes)


def wind(seconds):
    x = pink(seconds)
    t = t_axis(seconds)
    gust = 0.5 + 0.5 * np.sin(2 * np.pi * t / 6.6) * np.sin(2 * np.pi * t / 2.9 + 1)
    return band(x, 250, 1400) * (0.3 + 0.7 * gust)


def drum(seconds=0.6, f0=95, f1=42):
    hit = mix(thump(f0, f1, seconds, 9) * 1.2, lowpass(noise(0.05), 1200) * env(int(0.05 * RATE), 0.001, 0.01) * 0.5)
    return hit


def pattern(loop, beat, hits, sound, total):
    out = np.zeros(int(total * RATE))
    for bar_start in np.arange(0, total, loop):
        for step, level in hits:
            at = int((bar_start + step * beat) * RATE)
            if at < len(out):
                end = min(len(out), at + len(sound))
                out[at:end] += sound[: end - at] * level
    return out


def make_music():
    loop = 20.0
    total = loop + 2.0
    night = mix(drone(total, [55.0, 82.4], 380) * 0.9, wind(total) * 0.5)
    for at in (1.5, 8.2, 14.9):
        night = mix(night, pad(bell(220 if at < 10 else 196, 4.0, decay=1.6) * 0.18, at))
    save("ambiance_nuit", seamless(reverb(night, 2.5, 0.3)[: int(total * RATE)], loop), peak=0.55, loop=True)

    beat = 60.0 / 96.0  # 32 temps = 20 s
    heart = pattern(beat * 4, beat, [(0, 1.0), (0.75, 0.6), (2, 0.8), (3.5, 0.5)], drum(), total)
    duel = mix(drone(total, [55.0, 82.4, 110.0], 520) * 0.7, heart * 0.9, wind(total) * 0.25)
    save("ambiance_duel", seamless(reverb(duel, 1.8, 0.25)[: int(total * RATE)], loop), peak=0.6, loop=True)

    beat = 0.5  # 40 temps = 20 s
    war = pattern(beat * 4, beat, [(0, 1.0), (0.5, 0.5), (1, 0.8), (2, 1.0), (2.5, 0.5), (3, 0.7), (3.5, 0.6)], drum(0.5, 110, 45), total)
    low = pattern(beat * 8, beat, [(0, 1.0), (4, 1.0)], drum(1.0, 70, 30), total)
    choir = drone(total, [55.0, 58.3, 110.0, 164.8], 900) * (0.6 + 0.4 * np.sin(2 * np.pi * t_axis(total) / 5.0))
    lord = mix(choir * 0.65, war * 0.8, low * 0.9, wind(total) * 0.2)
    save("ambiance_seigneur", seamless(reverb(lord, 2.0, 0.3)[: int(total * RATE)], loop), peak=0.6, loop=True)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    make_combat()
    make_lords()
    make_ui()
    make_music()
