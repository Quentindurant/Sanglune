extends GutTest
## Le son, la vibration, les réglages et les trophées des seigneurs.

var store: MemoryProfileStore


func before_each() -> void:
    store = MemoryProfileStore.new()
    var sounds := Sfx.board()
    sounds.history.clear()
    sounds.vibrations.clear()
    sounds.apply(GameSettings.new())


func _button(parent: Node, text: String) -> Button:
    for child in parent.get_children():
        if child is Button and child.text == text:
            return child
    return null


func _flow() -> GameFlow:
    var flow := GameFlow.new()
    flow.store = store
    flow.random = RngRandomSource.new(3)
    add_child_autofree(flow)
    return flow


# --- Les sons ---

func test_every_sound_the_game_asks_for_exists() -> void:
    var used := [
        &"lame_legere", &"lame_lourde", &"coup", &"coup_lourd", &"parade", &"garde_brisee", &"ultime", &"ultime_impact",
        &"esquive", &"saut", &"reception", &"egide", &"ronces", &"venin", &"vol_de_vie", &"lune_presage", &"lune_impact",
        &"furie", &"seigneur", &"cloche_manche", &"victoire", &"defaite", &"clic", &"choix", &"rune_prete", &"butin",
        &"trophee", &"ambiance_nuit", &"ambiance_duel", &"ambiance_seigneur",
    ]
    for id: StringName in used:
        assert_true(ResourceLoader.exists(SoundBoard.AUDIO_DIR % id), "son manquant : %s" % id)


func test_the_sound_board_is_always_there() -> void:
    assert_not_null(Sfx.board(), "le nœud Sons est chargé avec le jeu")


func test_a_hit_in_a_duel_sounds_and_buzzes() -> void:
    var flow := _flow()
    (flow.current_screen as HomeScreen).play_requested.emit()
    var arena: Arena = flow.current_screen
    assert_eq(Sfx.board().current_music, &"ambiance_duel")
    arena.duel.events = [{"type": "hit", "side": 1, "action": CombatAction.Kind.FRAPPE}]
    arena._read_events()
    assert_true(&"coup" in Sfx.board().history)
    assert_eq(Sfx.board().vibrations[-1], Sfx.BUZZ_HIT, "le joueur touché sent le coup")
    arena.duel.events = [{"type": "blocked", "side": -1}]
    arena._read_events()
    assert_true(&"parade" in Sfx.board().history)


func test_a_swing_is_heard_when_the_blade_moves() -> void:
    var flow := _flow()
    (flow.current_screen as HomeScreen).play_requested.emit()
    var arena: Arena = flow.current_screen
    arena.duel.skip_intro()
    arena._sound_moves()
    arena.duel.left.request(CombatAction.Kind.FRAPPE)
    for i in 12:
        arena.duel.step(null, null)
        arena._sound_moves()
    assert_true(&"lame_legere" in Sfx.board().history, "le Veilleur fend l'air d'une lame légère")


func test_menus_play_the_night_and_a_lord_his_own_music() -> void:
    var flow := _flow()
    assert_eq(Sfx.board().current_music, &"ambiance_nuit")
    var hunt := flow.profile.start_hunt(HuntDifficulty.Level.PENOMBRE, 2)
    hunt.index = Hunt.BOSS_DUELS[0]
    flow.start_hunt_duel()
    assert_eq(Sfx.board().current_music, &"ambiance_seigneur")
    assert_true(&"seigneur" in Sfx.board().history, "le cor du seigneur")


func test_buttons_click() -> void:
    var button := UiStyle.make_button("Essai", false, Vector2(100, 50))
    add_child_autofree(button)
    button.pressed.emit()
    assert_eq(Sfx.board().history[-1], &"clic")


# --- Les réglages ---

func test_settings_default_and_bounds() -> void:
    var settings := GameSettings.new()
    assert_eq(settings.music, GameSettings.DEFAULT_MUSIC)
    assert_true(settings.vibration)
    var tampered := GameSettings.from_dict({"music": 99, "effects": -4, "vibration": "oui"})
    assert_eq(tampered.music, GameSettings.MAX_VOLUME)
    assert_eq(tampered.effects, 0)
    assert_true(tampered.vibration, "une valeur douteuse garde le réglage par défaut")
    assert_eq(GameSettings.to_db(0), -80.0)
    assert_almost_eq(GameSettings.to_db(10), 0.0, 0.01)


func test_settings_are_saved_with_the_profile() -> void:
    var profile := PlayerProfile.new()
    profile.set_music(2)
    profile.set_effects(9)
    profile.set_vibration(false)
    var back := PlayerProfile.from_dict(JSON.parse_string(JSON.stringify(profile.to_dict())))
    assert_eq(back.settings.music, 2)
    assert_eq(back.settings.effects, 9)
    assert_false(back.settings.vibration)


func test_no_vibration_when_the_player_turned_it_off() -> void:
    var settings := GameSettings.new()
    settings.vibration = false
    Sfx.apply(settings)
    Sfx.buzz(Sfx.BUZZ_HEAVY)
    assert_true(Sfx.board().vibrations.is_empty())


func test_silent_effects_are_not_played() -> void:
    var settings := GameSettings.new()
    settings.effects = 0
    Sfx.apply(settings)
    for voice in Sfx.board()._voices:
        voice.stop()
    Sfx.play(&"coup")
    for voice in Sfx.board()._voices:
        assert_false(voice.playing)


func test_the_settings_screen_steps_volumes_and_toggles_vibration() -> void:
    var profile := PlayerProfile.new()
    var screen := SettingsScreen.new(profile)
    add_child_autofree(screen)
    var minus := screen.get_children().filter(func(c: Node) -> bool: return c is Button and c.text == "−")
    var plus := screen.get_children().filter(func(c: Node) -> bool: return c is Button and c.text == "+")
    assert_eq(minus.size(), 2)
    minus[0].pressed.emit()
    assert_eq(profile.settings.music, GameSettings.DEFAULT_MUSIC - 1)
    for i in 20:
        plus[1].pressed.emit()
    assert_eq(profile.settings.effects, GameSettings.MAX_VOLUME, "jamais au-delà de dix")
    _button(screen, "Oui").pressed.emit()
    assert_false(profile.settings.vibration)
    assert_not_null(_button(screen, "Non"))


func test_settings_open_from_home_and_apply_at_once() -> void:
    var flow := _flow()
    (flow.current_screen as HomeScreen).settings_requested.emit()
    var screen: SettingsScreen = flow.current_screen
    assert_is(screen, SettingsScreen)
    screen.change_music(-6)
    assert_eq(Sfx.board().settings.music, 0, "la musique suit tout de suite")
    assert_eq(store.saved["settings"]["music"], 0)
    flow.go_back(false)
    assert_is(flow.current_screen, HomeScreen)


# --- Les trophées des seigneurs ---

func test_every_lord_leaves_a_unique_trophy() -> void:
    var looks := []
    for def in ItemCatalog.trophies():
        assert_true(def.trophy)
        assert_true(def.slot == ItemDef.Slot.HELM or def.slot == ItemDef.Slot.ARMOR)
        assert_false(def.look in looks, "%s : une silhouette à lui" % def.id)
        looks.append(def.look)
        var spec := KnightBuild.dressed(KnightClass.VEILLEUR, def.look)
        if def.look.has("crest"):
            assert_eq(spec["crest"], def.look["crest"])
            assert_false(KnightBuild.crest(spec["crest"], spec["helmet"]).is_empty(), "%s se dessine" % def.id)
    assert_eq(ItemCatalog.trophies().size(), Boss.ids().size())


func test_beating_a_lord_unlocks_his_trophy() -> void:
    var profile := PlayerProfile.new()
    var trophy := Boss.trophy_id(&"vipere")
    assert_false(profile.wardrobe.is_unlocked(trophy))
    profile.defeat_boss(&"vipere")
    assert_true(profile.wardrobe.is_unlocked(trophy))
    var slot := ItemCatalog.by_id(trophy).slot
    assert_true(profile.set_appearance(KnightClass.COLOSSE, slot, trophy), "n'importe quel chevalier peut le porter")
    assert_eq(profile.look(KnightClass.COLOSSE)["crest"], &"serpent")


func test_a_trophy_is_never_loot_nor_inventory() -> void:
    for slot in ItemDef.SLOTS:
        for def in LootTable.droppable(KnightClass.VEILLEUR, slot):
            assert_false(def.trophy)
    var profile := PlayerProfile.new()
    assert_null(profile.add_item(Boss.trophy_id(&"bastion"), Rarity.Tier.CROISSANT))
    assert_null(OwnedItem.from_dict({"uid": 3, "id": "trophee_bastion", "rarity": 0, "level": 1}))


func test_a_trophy_cannot_be_unlocked_by_editing_the_save() -> void:
    var profile := PlayerProfile.new()
    var data := profile.to_dict()
    data["wardrobe"]["unlocked"].append("trophee_furie")
    data["wardrobe"]["choices"] = {"veilleur": {"helm": "trophee_furie"}}
    var back := PlayerProfile.from_dict(JSON.parse_string(JSON.stringify(data)))
    assert_false(back.wardrobe.is_unlocked(Boss.trophy_id(&"furie")))
    assert_eq(back.wardrobe.choice(KnightClass.VEILLEUR, ItemDef.Slot.HELM), Wardrobe.FOLLOW)


func test_an_earned_trophy_and_its_choice_survive_the_save() -> void:
    var profile := PlayerProfile.new()
    profile.defeat_boss(&"furie")
    profile.set_appearance(KnightClass.VEILLEUR, ItemDef.Slot.HELM, Boss.trophy_id(&"furie"))
    var back := PlayerProfile.from_dict(JSON.parse_string(JSON.stringify(profile.to_dict())))
    assert_eq(back.wardrobe.choice(KnightClass.VEILLEUR, ItemDef.Slot.HELM), Boss.trophy_id(&"furie"))


func test_the_wardrobe_shows_a_trophy_only_once_earned() -> void:
    var profile := PlayerProfile.new()
    var hidden := WardrobeScreen.new(profile, KnightClass.VEILLEUR)
    add_child_autofree(hidden)
    for entry: Array in hidden.chips(ItemDef.Slot.HELM):
        assert_ne(entry[1], Boss.trophy_id(&"grand_veneur"), "secret tant qu'il n'est pas gagné")
    profile.defeat_boss(&"grand_veneur")
    profile.defeat_boss(&"increvable")
    var shown := WardrobeScreen.new(profile, KnightClass.VEILLEUR)
    add_child_autofree(shown)
    var values := shown.chips(ItemDef.Slot.HELM).map(func(entry: Array) -> StringName: return entry[1])
    assert_true(Boss.trophy_id(&"grand_veneur") in values)
    assert_true(Boss.trophy_id(&"increvable") in values)


func test_a_full_wardrobe_wraps_on_several_lines() -> void:
    var profile := PlayerProfile.new()
    for id in Boss.ids():
        profile.defeat_boss(id)
    var screen := WardrobeScreen.new(profile, KnightClass.VEILLEUR)
    add_child_autofree(screen)
    var chips := screen.chips(ItemDef.Slot.HELM)
    assert_gt(chips.size(), WardrobeScreen.PER_LINE)
    for entry: Array in chips:
        var chip: Button = entry[0]
        assert_true(chip.position.x + chip.size.x <= WardrobeScreen.VIEW.x, "rien ne déborde de l'écran")
        assert_true(chip.position.y + chip.size.y <= WardrobeScreen.VIEW.y)
