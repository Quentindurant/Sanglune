class_name GameSettings
extends RefCounted
## Les réglages du joueur : volume de la musique et des effets (0 à 10), et vibration.
## Sauvegardés avec le profil, revalidés à la relecture.

const MAX_VOLUME := 10
const DEFAULT_MUSIC := 6
const DEFAULT_EFFECTS := 8

var music := DEFAULT_MUSIC
var effects := DEFAULT_EFFECTS
var vibration := true


## Un volume de 0 à 10 en décibels pour le mixeur : 0 coupe, 10 vaut le niveau d'origine.
static func to_db(level: int) -> float:
    if level <= 0:
        return -80.0
    return linear_to_db(float(level) / MAX_VOLUME)


func to_dict() -> Dictionary:
    return {"music": music, "effects": effects, "vibration": vibration}


static func from_dict(data: Variant) -> GameSettings:
    var settings := GameSettings.new()
    if not data is Dictionary:
        return settings
    var stored_music: Variant = OwnedItem.whole_number(data.get("music"))
    var stored_effects: Variant = OwnedItem.whole_number(data.get("effects"))
    if stored_music is int:
        settings.music = clampi(stored_music, 0, MAX_VOLUME)
    if stored_effects is int:
        settings.effects = clampi(stored_effects, 0, MAX_VOLUME)
    if data.get("vibration") is bool:
        settings.vibration = data["vibration"]
    return settings
