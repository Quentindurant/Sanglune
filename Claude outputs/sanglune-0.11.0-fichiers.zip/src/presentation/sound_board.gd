class_name SoundBoard
extends Node
## Les sons et la vibration du jeu, toujours présents (autoload « Sons »). Les écrans passent par Sfx.
## Effets : plusieurs voix à la fois, une légère variation de hauteur pour qu'un même coup ne sonne jamais pareil.
## Musique : une ambiance en boucle, fondue dans la suivante quand on change d'écran.
## Volumes et vibration suivent les réglages du joueur (GameSettings).

const AUDIO_DIR := "res://assets/audio/%s.wav"
const VOICES := 12
const MUSIC_FADE := 0.9 ## secondes de fondu entre deux ambiances
const MUSIC_BASE_DB := -4.0 ## la musique reste sous les effets
const HISTORY := 24

var settings := GameSettings.new()
var history: Array[StringName] = [] ## derniers effets joués, pour les tests
var vibrations: Array[Vector2] = [] ## dernières vibrations demandées (durée, force), pour les tests
var current_music: StringName = &""
var _voices: Array[AudioStreamPlayer] = []
var _next_voice := 0
var _music: AudioStreamPlayer
var _fading_out: AudioStreamPlayer
var _cache := {} ## identifiant -> AudioStream
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS ## la pause d'un duel ne coupe pas les sons
    _rng.randomize()
    for i in VOICES:
        var voice := AudioStreamPlayer.new()
        add_child(voice)
        _voices.append(voice)
    _music = _make_music_player()
    _fading_out = _make_music_player()


## Applique les réglages : volume de la musique tout de suite, celui des effets au prochain son.
func apply(p_settings: GameSettings) -> void:
    settings = p_settings
    _music.volume_db = MUSIC_BASE_DB + GameSettings.to_db(settings.music)


## Joue un effet. volume_db : plus fort ou plus doux que l'enregistrement ; jitter : variation de hauteur.
func play(id: StringName, volume_db: float = 0.0, jitter: float = 0.06) -> void:
    _remember(id)
    if settings.effects <= 0:
        return
    var stream := _stream(id)
    if stream == null:
        return
    var voice := _voices[_next_voice]
    _next_voice = (_next_voice + 1) % _voices.size()
    voice.stream = stream
    voice.volume_db = volume_db + GameSettings.to_db(settings.effects)
    voice.pitch_scale = 1.0 + _rng.randf_range(-jitter, jitter)
    voice.play()


## Lance une ambiance en boucle, fondue avec la précédente. La même ambiance ne redémarre pas.
func music(id: StringName) -> void:
    if id == current_music:
        return
    current_music = id
    var stream := _stream(id) as AudioStreamWAV
    var swap := _fading_out
    _fading_out = _music
    _music = swap
    _fade(_fading_out, -80.0, true)
    if stream == null:
        return
    stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
    stream.loop_begin = 0
    stream.loop_end = int(stream.get_length() * stream.mix_rate)
    _music.stream = stream
    _music.volume_db = -60.0
    _music.play()
    _fade(_music, MUSIC_BASE_DB + GameSettings.to_db(settings.music), false)


## Fait vibrer le téléphone, si le joueur l'a permis. strength : de 0 à 1.
func vibrate(duration_ms: int, strength: float = 0.5) -> void:
    if not settings.vibration:
        return
    vibrations.append(Vector2(duration_ms, strength))
    if vibrations.size() > HISTORY:
        vibrations.pop_front()
    Input.vibrate_handheld(duration_ms, clampf(strength, 0.05, 1.0))


func _remember(id: StringName) -> void:
    history.append(id)
    if history.size() > HISTORY:
        history.pop_front()


func _stream(id: StringName) -> AudioStream:
    if not _cache.has(id):
        var path := AUDIO_DIR % id
        _cache[id] = load(path) if ResourceLoader.exists(path) else null
    return _cache[id]


func _make_music_player() -> AudioStreamPlayer:
    var player := AudioStreamPlayer.new()
    player.volume_db = -80.0
    add_child(player)
    return player


func _fade(player: AudioStreamPlayer, target_db: float, stop_after: bool) -> void:
    var tween := create_tween()
    tween.tween_property(player, "volume_db", target_db, MUSIC_FADE)
    if stop_after:
        tween.tween_callback(player.stop)
