class_name SettingsScreen
extends Control
## Réglages : volume de la musique, volume des effets, vibration. Grands boutons − et +, une jauge de dix crans,
## et un essai immédiat : on entend un effet, on sent la vibration. Tout est sauvegardé aussitôt.

signal closed

const VIEW := Vector2(1280, 720)
const ROW_Y := [210.0, 330.0, 450.0]
const LABEL_X := 170.0
const MINUS_X := 450.0
const BAR_X := 560.0
const SEGMENT := Vector2(34, 44)
const SEGMENT_GAP := 6.0
const STEP_BUTTON := Vector2(88, 72)
const BUTTON_TOP := 620.0
const BUTTON_HEIGHT := 76.0

var profile: PlayerProfile
var _vibration_button: Button


func _init(p_profile: PlayerProfile) -> void:
    profile = p_profile


func _ready() -> void:
    InputBindings.register()
    set_anchors_preset(Control.PRESET_FULL_RECT)
    _add_stepper(0, change_music, "musique")
    _add_stepper(1, change_effects, "effets")
    _vibration_button = UiStyle.make_button("", false, Vector2(220, STEP_BUTTON.y))
    _vibration_button.position = Vector2(MINUS_X, ROW_Y[2] - STEP_BUTTON.y / 2)
    _vibration_button.pressed.connect(toggle_vibration)
    add_child(_vibration_button)
    var back := UiStyle.make_button("Retour", false, Vector2(200, BUTTON_HEIGHT))
    back.position = Vector2(40, BUTTON_TOP)
    back.pressed.connect(closed.emit)
    add_child(back)
    _refresh()


func _process(_delta: float) -> void:
    queue_redraw()


## Monte ou baisse la musique d'un cran ; elle suit tout de suite.
func change_music(step: int) -> void:
    profile.set_music(profile.settings.music + step)
    _refresh()


## Monte ou baisse les effets d'un cran ; un coup de lame fait entendre le nouveau volume.
func change_effects(step: int) -> void:
    profile.set_effects(profile.settings.effects + step)
    Sfx.play(&"parade", 0.0, 0.0)
    _refresh()


func toggle_vibration() -> void:
    profile.set_vibration(not profile.settings.vibration)
    Sfx.buzz(Sfx.BUZZ_HIT)
    _refresh()


func go_back() -> bool:
    closed.emit()
    return true


func _add_stepper(row: int, action: Callable, what: String) -> void:
    var minus := UiStyle.make_button("−", false, STEP_BUTTON)
    minus.position = Vector2(MINUS_X, ROW_Y[row] - STEP_BUTTON.y / 2)
    minus.accessibility_name = "Baisser les " + what if what == "effets" else "Baisser la " + what
    minus.pressed.connect(action.bind(-1))
    add_child(minus)
    var plus := UiStyle.make_button("+", false, STEP_BUTTON)
    plus.position = Vector2(_bar_end() + 22, ROW_Y[row] - STEP_BUTTON.y / 2)
    plus.accessibility_name = "Monter les " + what if what == "effets" else "Monter la " + what
    plus.pressed.connect(action.bind(1))
    add_child(plus)


func _bar_end() -> float:
    return BAR_X + GameSettings.MAX_VOLUME * (SEGMENT.x + SEGMENT_GAP) - SEGMENT_GAP


func _refresh() -> void:
    _vibration_button.text = "Oui" if profile.settings.vibration else "Non"
    queue_redraw()


func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, VIEW), Palette.NIGHT)
    draw_circle(Vector2(VIEW.x - 150, 120), 60, Color(Palette.MOON, 0.10))
    draw_string(UiStyle.TITLE_FONT, Vector2(0, 90), "Réglages", HORIZONTAL_ALIGNMENT_CENTER, VIEW.x, 60, Palette.INK)
    var labels := ["Musique", "Effets", "Vibration"]
    for row in labels.size():
        draw_string(UiStyle.TEXT_FONT, Vector2(LABEL_X, ROW_Y[row] + 11), labels[row], HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Palette.INK)
    _draw_bar(ROW_Y[0], profile.settings.music)
    _draw_bar(ROW_Y[1], profile.settings.effects)


## Dix crans : allumés en cyan jusqu'au volume choisi ; tout éteint, le son est coupé.
func _draw_bar(center_y: float, level: int) -> void:
    for i in GameSettings.MAX_VOLUME:
        var rect := Rect2(Vector2(BAR_X + i * (SEGMENT.x + SEGMENT_GAP), center_y - SEGMENT.y / 2), SEGMENT)
        draw_rect(rect, Palette.CYAN if i < level else Color(Palette.QUIET, 0.18))
    if level == 0:
        draw_string(UiStyle.TEXT_FONT, Vector2(BAR_X, center_y + 46), "Coupé", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Palette.QUIET)
