class_name Sfx
extends RefCounted
## Raccourcis vers les sons et la vibration (le nœud « Sons » de SoundBoard). Sans lui, rien ne se passe :
## un écran testé seul n'a pas besoin du son.

const NODE_PATH := "Sons"

## Ce que ressent le pouce, en millisecondes et en force de 0 à 1.
const BUZZ_LIGHT := Vector2(18, 0.25) ## ton coup qui porte
const BUZZ_HIT := Vector2(45, 0.55) ## un coup reçu
const BUZZ_HEAVY := Vector2(90, 0.8) ## garde brisée, plongeon reçu
const BUZZ_ULTIMATE := Vector2(140, 1.0) ## un ultime, la lune


static func board() -> SoundBoard:
    var loop := Engine.get_main_loop()
    if loop is SceneTree and (loop as SceneTree).root != null:
        return (loop as SceneTree).root.get_node_or_null(NODE_PATH) as SoundBoard
    return null


static func play(id: StringName, volume_db: float = 0.0, jitter: float = 0.06) -> void:
    var sounds := board()
    if sounds != null:
        sounds.play(id, volume_db, jitter)


static func music(id: StringName) -> void:
    var sounds := board()
    if sounds != null:
        sounds.music(id)


static func buzz(pattern: Vector2) -> void:
    var sounds := board()
    if sounds != null:
        sounds.vibrate(int(pattern.x), pattern.y)


static func apply(settings: GameSettings) -> void:
    var sounds := board()
    if sounds != null:
        sounds.apply(settings)
